﻿		jQuery(function(){
			
			jQuery('#camera_wrap_1').camera({
				pagination: false,
				loader: 'none',
				height:'35%',
				easing: 'easeOutBounce',
				fx					: 'random',
				thumbnails: false
			});

		});