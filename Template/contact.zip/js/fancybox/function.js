		$(document).ready(function() {

			$("a.zoom").attr('rel', 'gallery').fancybox({
				'titleShow' : true,
				
				helpers: {
					title : {
						type : 'float'
							}
							}
			});

		});
		
		
