			$(document).ready(function(){
				$('#iview').iView({
					fx: 'random',
					pauseTime: 7000,
					pauseOnHover: true,
					directionNavHoverOpacity: 0,
					timer: "none",
					timerDiameter: "100%",
					timerPadding: 0,
					timerStroke:1,
					timerBarStroke: 0,
					timerBg:"#e9e9e9",
					timerOpacity:1,
					timerColor: "#ff5408",
					timerY:0,
					timerX:0,
					timerPosition: "bottom-left"
				});
			});